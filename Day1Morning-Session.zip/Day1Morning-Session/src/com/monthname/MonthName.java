package com.monthname;
import java.util.Scanner;
public class MonthName {
	public static void main(String[] args) {
        // Create a Scanner object to read input from the user
   Scanner scanner = new Scanner(System.in);
 
        // Prompt the user to enter a number between 1 to 12
        System.out.print("Enter a number between 1 to 12: ");
        int monthNumber = scanner.nextInt();
 
        // Close the scanner
        scanner.close();
 
        // Check if the entered number is within the valid range
        if (monthNumber >= 1 && monthNumber <= 12) {
            // Use switch statement to display the name of the month
            switch (monthNumber) {
                case 1:
                    System.out.println("January");
                    break;
                case 2:
                    System.out.println("February");
                    break;
                case 3:
                    System.out.println("March");
                    break;
                case 4:
                    System.out.println("April");
                    break;
                case 5:
                    System.out.println("May");
                    break;
                case 6:
                    System.out.println("June");
                    break;
                case 7:
                    System.out.println("July");
                    break;
                case 8:
                    System.out.println("August");
                    break;
                case 9:
                    System.out.println("September");
                    break;
                case 10:
                    System.out.println("October");
                    break;
                case 11:
                    System.out.println("November");
                    break;
                case 12:
                    System.out.println("December");
                    break;
            }
        } else {
            // Display a message if the entered number is not within the valid range
            System.out.println("Invalid input.");
        }
    }
}
