package com.question4;

import java.util.HashSet;

public class ProductRemoval {
	public static void main(String[] args) {
	
		HashSet<Product> products = new HashSet<>();

	
		products.add(new Product("P001", "Maruti 800"));
		products.add(new Product("P002", "Maruti Zen"));
		products.add(new Product("P003", "Maruti Dezire"));
		products.add(new Product("P004", "Maruti Alto"));

		
		String productIdToRemove = "P002";

	
		Product productToRemove = new Product(productIdToRemove, "");


		boolean removed = products.remove(productToRemove);

		if (removed) {
			System.out.println("Product with ID " + productIdToRemove + " removed successfully.");
		} else {
			System.out.println("Product with ID " + productIdToRemove + " not found.");
		}

	
		System.out.println("Updated Product List:");
		for (Product product : products) {
			System.out.println(product);
		}
	}
}