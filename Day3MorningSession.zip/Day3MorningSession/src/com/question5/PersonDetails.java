package com.question5;

import java.util.TreeSet;

public class PersonDetails {
	public static void main(String[] args) {
		
		TreeSet<Person> persons = new TreeSet<>();


		persons.add(new Person(1, "Alice", 22, 1500.0));
		persons.add(new Person(2, "Bob", 28, 2500.0));
		persons.add(new Person(3, "Charlie", 35, 3500.0));
		persons.add(new Person(4, "David", 20, 1000.0));
		persons.add(new Person(5, "John", 32, 1999.0));
		persons.add(new Person(6, "Tom", 42, 3999.0));

	
		System.out.println("Persons details whose age is greater than 25:");
		for (Person person : persons) {
			if (person.getAge() > 25) {
				System.out.println(person);
			}
		}
	}
}