package com.question7;

import java.util.Map;
import java.util.TreeMap;

public class CarDetails {
	public static void main(String[] args) {
	
		TreeMap<Car, Double> carMap = new TreeMap<>();

		
		carMap.put(new Car("Bugatti", 80050.0), 80050.0);
		carMap.put(new Car("Swift", 305000.0), 305000.0);
		carMap.put(new Car("Audi", 600100.0), 600100.0);
		carMap.put(new Car("Benz", 900000.0), 900000.0);


		Map.Entry<Car, Double> greatestEntry = carMap.lastEntry();
		System.out.println(greatestEntry.getKey());

	
		Map.Entry<Car, Double> leastEntry = carMap.firstEntry();
		System.out.println(leastEntry.getKey());
	}
}
