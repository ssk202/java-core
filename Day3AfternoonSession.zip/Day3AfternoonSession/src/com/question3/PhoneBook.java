package com.question3;

import java.time.LocalDate;
import java.util.TreeSet;

class Book implements Comparable<Book> {
	private int bookId;
	private String title;
	private double price;
	private String author;
	private LocalDate publicationDate;

	public Book(int bookId, String title, double price, String author, LocalDate publicationDate) {
		this.bookId = bookId;
		this.title = title;
		this.price = price;
		this.author = author;
		this.publicationDate = publicationDate;
	}

	public int getBookId() {
		return bookId;
	}

	@Override
	public String toString() {
		return bookId + " " + title + " " + price + " " + author + " " + publicationDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bookId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return bookId == other.bookId;
	}

	@Override
	public int compareTo(Book other) {
		return Integer.compare(this.bookId, other.bookId);
	}
}


