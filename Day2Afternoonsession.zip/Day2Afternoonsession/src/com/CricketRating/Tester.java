package com.CricketRating;
public class Tester {
    public static void main(String[] args) {
        try {
            // Creating a CricketRating object with two critics
            CricketRating player1 = new CricketRating("John", 9.3f, 9.67f);
            player1.display(); // Displaying player information

            // Creating a CricketRating object with three critics
           // CricketRating player2 = new CricketRating("Alice", 6.5f, 7.8f, 8.2f);
           // player2.display(); // Displaying player information

            // Creating a CricketRating object with an average rating less than 2
            CricketRating player3 = new CricketRating("Bob", 1.5f, 2.0f);
            player3.display(); // This will print the exception message
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}