package com.exceptionhandling;
public class Main {
    public static void main(String[] args) {
        try {
            BankAccount account = new BankAccount(123, "John", "Saving", 900);
            account.deposit(200); // Depositing 200 into the account
            float balance = account.getBalance(); // Getting the current balance
            System.out.println("Current balance: " + balance);
        } catch (LowBalanceException e) {
            System.out.println("LowBalance");
        } catch (NegativeAmountException e) {
            System.out.println("NegativeAmountException: " + e.getMessage());
        }
    }
}