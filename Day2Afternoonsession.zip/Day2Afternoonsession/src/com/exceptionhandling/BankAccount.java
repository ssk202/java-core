package com.exceptionhandling;
class LowBalanceException extends Exception {
    public LowBalanceException(String message) {
        super(message);
    }
}

class NegativeAmountException extends Exception {
    public NegativeAmountException(String message) {
        super(message);
    }
}

public class BankAccount {
    private int accNo;
    private String custName;
    private String accType;
    private float balance;

    public BankAccount(int accNo, String custName, String accType, float initialBalance) throws LowBalanceException, NegativeAmountException {
        this.accNo = accNo;
        this.custName = custName;
        this.accType = accType;
        
        if (initialBalance < 0) {
            throw new NegativeAmountException(" negative balance.");
        }

        if ((accType.equals("Saving") && initialBalance < 1000) || (accType.equals("Current") && initialBalance < 5000)) {
            throw new LowBalanceException("LowBalance");
        }

        this.balance = initialBalance;
    }

    public void deposit(float amt) throws NegativeAmountException {
        if (amt < 0) {
            throw new NegativeAmountException("Cannot deposit negative amount.");
        }
        balance += amt;
    }

    public float getBalance() throws LowBalanceException {
        if ((balance < 1000 && accType.equals("Saving")) || (balance < 5000 && accType.equals("Current"))) {
            throw new LowBalanceException("LowBalance");
        }
        return balance;
    }
}