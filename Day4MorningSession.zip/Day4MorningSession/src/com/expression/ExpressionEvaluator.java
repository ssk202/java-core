package com.expression;
import java.util.Stack;

public class ExpressionEvaluator {

	public static int evaluateExpression(String expression) {
	expression = expression.replaceAll("\\s+", "");
		Stack<Integer> numbers = new Stack<>();

		Stack<Character> operators = new Stack<>();

		for (int i = 0; i < expression.length(); i++) {
			char c = expression.charAt(i);

			if (Character.isDigit(c)) {
				StringBuilder num = new StringBuilder();
				
				while (i < expression.length() && Character.isDigit(expression.charAt(i))) {
					num.append(expression.charAt(i));
					i++;
				}
				
				numbers.push(Integer.parseInt(num.toString()));
				
				i--;
			} else if (c == '(') {
		
				operators.push(c);
			} else if (c == ')') {
				
				while (operators.peek() != '(') {
					numbers.push(applyOperation(operators.pop(), numbers.pop(), numbers.pop()));
				}
				
				operators.pop();
			} else if (c == '+' || c == '-' || c == '*' || c == '/') {
				
				while (!operators.isEmpty() && hasPrecedence(c, operators.peek())) {
					numbers.push(applyOperation(operators.pop(), numbers.pop(), numbers.pop()));
				}
				
				operators.push(c);
			}
		}

	
		while (!operators.isEmpty()) {
			numbers.push(applyOperation(operators.pop(), numbers.pop(), numbers.pop()));
		}

		
		return numbers.pop();
	}

	
	private static boolean hasPrecedence(char operator1, char operator2) {
		return (operator2 != '(' && operator2 != ')'
				&& ((operator1 == '*' || operator1 == '/') || (operator2 == '+' || operator2 == '-')));
	}


	private static int applyOperation(char operator, int operand2, int operand1) {
		switch (operator) {
		case '+':
			return operand1 + operand2;
		case '-':
			return operand1 - operand2;
		case '*':
			return operand1 * operand2;
		case '/':
			if (operand2 == 0)
				throw new ArithmeticException("Cannot divide by zero");
			return operand1 / operand2;
		default:
			return 0;
		}
	}

	public static void main(String[] args) {
		String expression = "10 + 2 * 6";
		int result = evaluateExpression(expression);
		System.out.println("Result: " + result);
	}
}