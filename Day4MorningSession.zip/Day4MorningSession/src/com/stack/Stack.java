package com.stack;

public class Stack {
	private int maxSize;
	private String[] stackArray;
	private int top;

	public Stack(int size) {
		this.maxSize = size;
		this.stackArray = new String[maxSize];
		this.top = -1;
	}

	public boolean isEmpty() {
		return top == -1;
	}

	public boolean isFull() {
		return top == maxSize - 1;
	}

	public void push(String item) {
		if (isFull()) {
			System.out.println("Stack Overflow");
		} else {
			top++;
			stackArray[top] = item;
		}
	}

	public String pop() {
		if (isEmpty()) {
			System.out.println("Stack Underflow");
			return null;
		} else {
			String poppedItem = stackArray[top];
			top--;
			return poppedItem;
		}
	}

	public void display() {
		if (isEmpty()) {
			System.out.println("Stack is empty");
		} else {
			System.out.print("Stack Elements: ");
			for (int i = 0; i <= top; i++) {
				System.out.print(stackArray[i] + " ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Stack stack = new Stack(5);
		stack.push("Hello");
		stack.push("world");
		stack.push("java");
		stack.push("Programming");

		System.out.println("After Pushing 4 Elements:");
		stack.display();

		System.out.println("After a Pop:");
		stack.pop();
		stack.display();
	}
}