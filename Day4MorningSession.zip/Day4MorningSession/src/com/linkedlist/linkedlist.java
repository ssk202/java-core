package com.linkedlist;

public class linkedlist {
	public static void main(String[] args) {
		Stack stack = new Stack();
		String input = "10.0 20.0 30.0 40.0";
		String[] values = input.split(" ");

		for (String value : values) {
			double data = Double.parseDouble(value);
			stack.push(data);
		}

		stack.display();
		System.out.println("Popped element: " + stack.pop());
		System.out.println("Top element: " + stack.peek());
	}
}