package com.stringsplit;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class FourDistinctStrings {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String input = scanner.nextLine();

		boolean canSplit = canSplitIntoFourDistinctStrings(input);

		if (canSplit) {
			System.out.println("The string can be split into four distinct strings.");
		} else {
			System.out.println("The string cannot be split into four distinct strings.");
		}

		scanner.close();
	}

	public static boolean canSplitIntoFourDistinctStrings(String str) {
		if (str.length() < 4) {
			return false;
		}

		Set<String> set = new HashSet<>();
		for (int i = 1; i < str.length() - 2; i++) {
			for (int j = i + 1; j < str.length() - 1; j++) {
				for (int k = j + 1; k < str.length(); k++) {
					String substr1 = str.substring(0, i);
					String substr2 = str.substring(i, j);
					String substr3 = str.substring(j, k);
					String substr4 = str.substring(k);
					set.clear();
					set.add(substr1);
					set.add(substr2);
					set.add(substr3);
					set.add(substr4);
					if (set.size() == 4) {
						return true;
					}
				}
			}
		}
		return false; 
	}
}